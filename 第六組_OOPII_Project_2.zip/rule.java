import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color.*;
import javax.swing.Box;
import javax.swing.JScrollPane;

public class rule extends JFrame {
	public static final int WIDTH=1000;
	public static final int HEIGHT=750;
	// private final JTextArea jTextArea1;
	// private final JTextArea jTextArea2;
	// private final JTextArea jTextArea3;
	// private final JTextArea jTextArea;

	public rule()
	{
		
		super("rule");
		setSize(WIDTH,HEIGHT);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		rulePage panel = new rulePage();
		// JTextArea content = new JTextArea(100,10) ;
		JScrollPane g = new JScrollPane(panel);
		g.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		// g.setBounds(110,10,200,100);
		add(g);
		// add(panel);	    
		
	   
	}
	class rulePage extends JPanel
    {
        ImageIcon sdgin = new ImageIcon("./picture/rule.png");
        Image sdg = sdgin.getImage();

        public rulePage()
        {}
        public void paint(Graphics g)
        {
            g.drawImage(sdg,250,0,null);
		}
		

    }
}
