import javax.swing.JLabel;
import javax.swing.*;
import java.awt.*;

public class Card extends JLabel
{
    private int number;
    private boolean onclick;

    public Card(int number)
    {
        this.number=number;
        this.onclick = false;

        if(number==1)
        {
            Icon green=new ImageIcon("./picture/green.png");
		    setIcon(green);
		    setPreferredSize(new Dimension(100,180));
        }
        else if(number==2)
        {
            Icon yellow=new ImageIcon("./picture/yellow.png");
		    setIcon(yellow);
		    setPreferredSize(new Dimension(100,180));
        }
        else if(number==3)
        {
            Icon grey=new ImageIcon("./picture/grey.png");
		    setIcon(grey);
		    setPreferredSize(new Dimension(100,180));
        }
        else if(number==4)
        {
            Icon purple=new ImageIcon("./picture/purple.png");
		    setIcon(purple);
		    setPreferredSize(new Dimension(100,180));
        }
        else if(number==5)
        {
            Icon red=new ImageIcon("./picture/red.png");
		    setIcon(red);
		    setPreferredSize(new Dimension(100,180));
        }
        else if(number==6)
        {
            Icon blue=new ImageIcon("./picture/blue.png");
		    setIcon(blue);
		    setPreferredSize(new Dimension(100,180));
        }
    }

    public int getNumber(){
        return this.number;
    }
    public boolean getonclick(){
        return this.onclick;
    }
    public void setonclick(boolean onclick){
        this.onclick = onclick;
    }
}
